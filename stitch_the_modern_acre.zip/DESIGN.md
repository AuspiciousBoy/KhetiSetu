---
name: Agri-Modernism
colors:
  surface: '#fdf9f0'
  surface-dim: '#dddad1'
  surface-bright: '#fdf9f0'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3ea'
  surface-container: '#f1eee5'
  surface-container-high: '#ece8df'
  surface-container-highest: '#e6e2d9'
  on-surface: '#1c1c16'
  on-surface-variant: '#424844'
  inverse-surface: '#31302b'
  inverse-on-surface: '#f4f0e7'
  outline: '#727974'
  outline-variant: '#c2c8c3'
  surface-tint: '#486458'
  primary: '#08241a'
  on-primary: '#ffffff'
  primary-container: '#1f3a2f'
  on-primary-container: '#86a496'
  inverse-primary: '#afcdbe'
  secondary: '#785838'
  on-secondary: '#ffffff'
  secondary-container: '#fdd2aa'
  on-secondary-container: '#795939'
  tertiary: '#3c1200'
  on-tertiary: '#ffffff'
  tertiary-container: '#5f2100'
  on-tertiary-container: '#e78353'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cbead9'
  primary-fixed-dim: '#afcdbe'
  on-primary-fixed: '#042016'
  on-primary-fixed-variant: '#314c41'
  secondary-fixed: '#ffdcbd'
  secondary-fixed-dim: '#e9bf98'
  on-secondary-fixed: '#2c1600'
  on-secondary-fixed-variant: '#5e4123'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb595'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7a3005'
  background: '#fdf9f0'
  on-background: '#1c1c16'
  surface-variant: '#e6e2d9'
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  display-sm:
    fontFamily: Sora
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
  container-max: 1440px
---

## Brand & Style

This design system blends high-end editorial aesthetics with the raw, rhythmic patterns of modern agriculture. The brand personality is authoritative yet grounded, evoking the feeling of a premium architectural journal focused on the land. 

The visual style is **Modern-Minimalist with Organic Inflections**. It draws heavily from Scandinavian functionalism—prioritizing clarity and utility—while introducing "soft brutalism" through bold typography and structural grid lines. The emotional response should be one of calm, professional stewardship and precision. Use expansive whitespace to symbolize the scale of open fields, and implement organic, sweeping curves in layout containers to mimic aerial topographical views.

## Colors

The palette is rooted in the natural world but rendered with a sophisticated, desaturated finish. 

- **Primary (Deep Forest):** Used for primary actions, navigation backgrounds, and high-level structural elements. It provides the "anchor" for the brand.
- **Secondary (Earth Brown):** Reserved for data visualization accents, secondary buttons, and specific categorical tags related to soil or harvest.
- **Tertiary (Terracotta):** An energetic accent used sparingly for notifications, critical alerts, or "Call to Action" highlights to draw the eye immediately.
- **Surface Palette (Warm Beige & Soft Sand):** Used for cards and container backgrounds to create soft separation without the harshness of pure white.
- **Background (Off White):** The base canvas for the entire application, providing a warm, tactile feel.

## Typography

The typography follows a strict editorial hierarchy. **Sora** is used for all display and headline roles to provide a geometric, modern tech feel. **Inter** handles all functional and long-form text, ensuring maximum readability for data-heavy agricultural reports.

For an editorial feel, headlines should be tightly tracked (`-0.01em` to `-0.02em`) and given ample vertical room. Labels and captions should use wider tracking (`0.05em`) and uppercase styling to act as clear navigational signposts.

## Layout & Spacing

This design system utilizes a **12-column fixed-width grid** for desktop, centered within the viewport. The spacing rhythm is based on a **linear 8px scale**, but the primary differentiator is the "Editorial Margin"—vast, intentional gaps between major content sections (often 80px or 120px) to prevent information density fatigue.

- **Desktop:** 12 columns | 24px gutters | 64px outer margins.
- **Tablet:** 8 columns | 20px gutters | 40px outer margins.
- **Mobile:** 4 columns | 16px gutters | 20px outer margins.

Layouts should favor asymmetrical compositions; for example, a 4-column sidebar for metadata paired with an 8-column main content area for charts and maps.

## Elevation & Depth

Hierarchy is achieved through **Tonal Layering** supplemented by **Ambient Shadows**. 

Instead of traditional drop shadows, this design system uses "diffused soil shadows"—long, soft blurs with a very low opacity (3-5%) tinted with the `Secondary` Earth Brown color. 

1.  **Level 0 (Base):** Off-White background.
2.  **Level 1 (Cards):** Warm Beige surface, no shadow, 1px Soft Sand border.
3.  **Level 2 (Floating/Interactive):** Warm Beige surface, 16px blur ambient shadow, used for active states or modals.

Subtle grain textures (2% opacity) should be applied to large Deep Forest surfaces to mimic organic matter and reduce the "digital" coldness of flat blocks of color.

## Shapes

The shape language is defined by large, generous radii that reflect the "organic curves" of agricultural landscapes. 

Standard components use a **16px** (rounded-lg) radius. Large layout containers or featured image modules should use **24px** (rounded-xl) or even **32px** to create a soft, premium feel. 

Buttons and input fields maintain a consistent **12px** radius to feel modern and accessible. Avoid pill-shaped buttons; the "Agri-Modernism" aesthetic relies on structured, squircle-like geometry.

## Components

### Buttons & Inputs
- **Primary Button:** Deep Forest background, Off-White text. 12px radius. Heavy weight Inter font.
- **Secondary Button:** 1px Earth Brown border, no fill, Earth Brown text.
- **Inputs:** Soft Sand background, no border. On focus, transition to a 1px Deep Forest border.

### Cards & Progress
- **Feature Cards:** Use 24px corner radius. Incorporate a subtle "grain" texture overlay.
- **Progress Rings:** Use thick strokes (8-12px) with rounded caps. Primary color for progress, Soft Sand for the track.
- **Charts:** Use "Deep Forest" for primary data lines and "Terracotta" for anomalous peaks. Background grids should be "Soft Sand" at 0.5px width.

### Timeline & Schemes
- **Timeline:** A vertical 2px Soft Sand line. Active nodes are Deep Forest circles with a 4px white inner dot.
- **Chips:** Small, 4px rounded corners (Soft), Earth Brown text on Warm Beige background. Use for "Soil Type" or "Crop Status."

### Icons
- Use thin-stroke (1.5pt) monolinear icons. Icons should be encased in a Soft Sand circular tile when used in navigation or as standalone triggers.